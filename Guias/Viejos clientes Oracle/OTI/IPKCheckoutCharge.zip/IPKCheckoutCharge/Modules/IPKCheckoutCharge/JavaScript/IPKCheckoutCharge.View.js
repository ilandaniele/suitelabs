define('IPKCheckoutCharge.View'
,	[
		'Wizard.Module'
	,	'Profile.Model'
	,	'SC.Configuration'
	,	'Utils'
	,	'Backbone'
	,	'jQuery'
	,	'underscore'
	]
,	function (
		WizardModule
	,	ProfileModel
	,	SCConfiguration
	,	Utils
	,	Backbone
	,	jQuery
	,	_
	)
{
	'use strict';

	// @class equip.EquipCheckoutFields.EquipCheckoutFields.View @extends Backbone.View
	return WizardModule.extend({
		submit: function ()
		{
			console.log('this', this);
			// if (error.error) {
			// 	return jQuery.Deferred().reject(error.message);
			// }
			
			var self = this;
			var payment = self.wizard.model.get('paymentmethods').models;
			var paymentmethod;
			var container = self.wizard.application.getComponent('Cart');
			console.log('payment', payment);
			if (payment && payment.length) {
				console.log('payment here111111',);
				paymentmethod = payment[0].get('type');
			}
			console.log('paymentmethod', paymentmethod);
			if(paymentmethod == 'creditcard') {
				console.log('addline here');
				container.addLine({
			        line: {
			            quantity: 1,
			            item: {
			                internalid: '1823'
			            }
			        }
			    }).then(function()
			  {alert(Utils.translate('Item added.'))});
			}

			return jQuery.Deferred().resolve();
		}
	});
});