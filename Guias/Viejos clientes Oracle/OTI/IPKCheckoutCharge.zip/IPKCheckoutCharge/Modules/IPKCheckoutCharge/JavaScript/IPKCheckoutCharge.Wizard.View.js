define('IPKCheckoutCharge.Wizard.View', [
    'Wizard.View',
    'SC.Configuration',
    'GlobalViews.Message.View',
    'underscore',
    'Utils'
], function StudentAccountWizardView (
    WizardView,
    Configuration,
    GlobalViewsMessageView,
    _,
    Utils
) {
    'use strict';

    _.extend(WizardView.prototype, {
        getContext: _.wrap(WizardView.prototype.getContext, function initialize(e) {
            var context = e.apply(this, _.toArray(arguments).slice(1));
            var self = this;
            console.log('this context', this);
            _.defer(function() {
                var payment = self.wizard.model.get('paymentmethods').models;
                var paymentmethod;
                var config = Configuration.get('checkoutcharge');

                if (!config.active) {
                    e.apply(this, _.toArray(arguments).slice(1));
                    return true;
                }
                
                var disclaimer = config.disclaimer;
                var percentage = config.percent;
                var label = config.summarylabel;
                var hasCharge;

                if (payment && payment.length) {

                    paymentmethod = payment[0].get('type');
                }

                if(paymentmethod == 'creditcard') {
                    var globalViewMessage = new GlobalViewsMessageView({
                        message: disclaimer,
                        type: 'error',
                        closable: true
                    });

                    var messages = globalViewMessage.render().$el.html();
                    messages = '<div class="checkout-charge-container">'+ messages + '</div>';

                    jQuery('.checkout-charge-container').remove();
                    jQuery('.order-wizard-paymentmethod-selector-module-header-nav').after(messages);

                    var summary = self.wizard.model.get('summary');
                    var total = summary.total;
                    var totalPercentage = total * (parseInt(percentage) / 100);
                    totalPercentage = totalPercentage.toFixed(2);
                    total = parseFloat(total) + parseFloat(totalPercentage);
                    total = parseFloat(total);
                    total = total.toFixed(2);

                    totalPercentage = Utils.formatCurrency(totalPercentage);
                    total = Utils.formatCurrency(total);
                    
					var container = jQuery('.order-wizard-cart-summary-shipping-cost-applied');
					container.after(
						'<div class="order-wizard-cart-summary-shipping-cost-applied inpk-checkout-charge">'
                            +'<p class="order-wizard-cart-summary-grid-float">'
                                +'<span class="order-wizard-cart-summary-shipping-cost-formatted">'
                                    +totalPercentage
                                +'</span>'
                                +label
                            +'</p>'
                        +'</div>'
                    )
                    
                    var totalContainer = jQuery('.order-wizard-cart-summary-total').find('.order-wizard-cart-summary-grid-right');
                    totalContainer.html(total);
                }
                else {
                    jQuery('.checkout-charge-container').remove();
                }
            });

            return context;
        })
     ,   submit: _.wrap(WizardView.prototype.submit, function submit(e) {

            var self = this;
            var payment = self.wizard.model.get('paymentmethods').models;
            var paymentmethod;
            var config = Configuration.get('checkoutcharge');

			if (!config.active) {
                e.apply(this, _.toArray(arguments).slice(1));
                return true;
            }

            if (payment && payment.length) {
				paymentmethod = payment[0].get('type');
			}

			if(paymentmethod == 'creditcard' || paymentmethod == 'invoice') {
                this.wizard.model.get('options').custbody_nsps_add_charge =  "T";
            }
            else {
                this.wizard.model.get('options').custbody_nsps_add_charge =  "F";
            }

            e.apply(this, _.toArray(arguments).slice(1));
        })
    });
});
