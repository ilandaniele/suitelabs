define('IPKCheckoutCharge.OrderWizard.Module.PaymentMethod.Selector', [
    'OrderWizard.Module.PaymentMethod.Selector',
    'SC.Configuration',
    'GlobalViews.Message.View',
    'underscore',
    'Utils'
], function StudentAccountOrderWizardModulePaymentMethodSelector(
    OrderWizardModulePaymentMethodSelector,
    Configuration,
    GlobalViewsMessageView,
    _,
    Utils
) {
    'use strict';

    _.extend(OrderWizardModulePaymentMethodSelector.prototype, {
        selectPaymentMethod: _.wrap(OrderWizardModulePaymentMethodSelector.prototype.selectPaymentMethod, function selectPaymentMethod(fn) {
			fn.apply(this, _.toArray(arguments).slice(1));
            
            var self = this;

            _.defer(function() {
                var paymentmethod = jQuery('.order-wizard-paymentmethod-selector-module-button.selected').text();
                var config = Configuration.get('checkoutcharge');

                if (!config.active) {
                    e.apply(this, _.toArray(arguments).slice(1));
                    return true;
                }
                
                var disclaimer = config.disclaimer;
                var percentage = config.percent;
                var label = config.summarylabel;

                if(paymentmethod.trim() == 'Credit / Debit Card') {

                    var globalViewMessage = new GlobalViewsMessageView({
                        message: disclaimer,
                        type: 'error',
                        closable: true
                    });

                    var messages = globalViewMessage.render().$el.html();
                    messages = '<div class="checkout-charge-container">'+ messages + '</div>';

                    jQuery('.checkout-charge-container').remove();
                    jQuery('.order-wizard-paymentmethod-selector-module-header-nav').after(messages);

                    var summary = self.wizard.model.get('summary');
                    var total = summary.total;
                    var totalPercentage = total * (parseInt(percentage) / 100);
                    totalPercentage = totalPercentage.toFixed(2);
                    total = parseFloat(total) + parseFloat(totalPercentage);
                    total = parseFloat(total);
                    total = total.toFixed(2);

                    totalPercentage = Utils.formatCurrency(totalPercentage);
                    total = Utils.formatCurrency(total);
                    
                    var container = jQuery('.order-wizard-cart-summary-shipping-cost-applied');
                    jQuery('.inpk-checkout-charge').remove();
					container.after(
						'<div class="order-wizard-cart-summary-shipping-cost-applied inpk-checkout-charge">'
                            +'<p class="order-wizard-cart-summary-grid-float">'
                                +'<span class="order-wizard-cart-summary-shipping-cost-formatted">'
                                    +totalPercentage
                                +'</span>'
                                +label
                            +'</p>'
                        +'</div>'
                    )
                    
                    var totalContainer = jQuery('.order-wizard-cart-summary-total').find('.order-wizard-cart-summary-grid-right');
                    totalContainer.html(total);
                }
                else {
                    jQuery('.checkout-charge-container').remove();
                    jQuery('.inpk-checkout-charge').remove();
                    
                    var summary = self.wizard.model.get('summary');
                    var total = summary.total;
                    total = Utils.formatCurrency(total);

                    var totalContainer = jQuery('.order-wizard-cart-summary-total').find('.order-wizard-cart-summary-grid-right');
                    totalContainer.html(total);
                }
            });
        })
    });
});
