
define(
	'IPKCheckoutCharge.Shopping'
,   [
		'IPKCheckoutCharge.Wizard.View'
	,	'IPKCheckoutCharge.OrderWizard.Module.PaymentMethod.Selector'
		// 'IPKCheckoutCharge.View'
	]
,   function (
		IPKCheckoutChargeWizardView
	,	IPKCheckoutChargeOrderWizardModulePaymentMethodSelector
		// IPKCheckoutChargeView
	)
{
	'use strict';

	return  {
		mountToApp: function mountToApp (container)
		{
			// var checkout = container.getComponent('Checkout');
			// if(checkout) {
			// 	checkout.addModuleToStep({
			// 		step_url: 'billing'
			// 	,	module: {
			// 			id: 'IPKCheckoutChargeView'
			// 		,	index: 6
			// 		,	classname: 'IPKCheckoutCharge.View'
			// 		}
			// 	})
			// }
		}
	};
});
