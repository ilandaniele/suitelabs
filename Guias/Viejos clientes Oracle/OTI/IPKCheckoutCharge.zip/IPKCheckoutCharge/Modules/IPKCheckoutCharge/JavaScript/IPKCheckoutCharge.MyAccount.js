
define(
	'IPKCheckoutCharge.MyAccount'
,   [
		'IPKCheckoutCharge.Wizard.View.MyAccount'
	,	'IPKCheckoutCharge.OrderWizard.Module.PaymentMethod.Selector.MyAccount'
	]
,   function (
		IPKCheckoutChargeWizardView
	,	IPKCheckoutChargeOrderWizardModulePaymentMethodSelector
	)
{
	'use strict';

	return  {
		mountToApp: function mountToApp (container)
		{
		}
	};
});
