define('IPKCheckoutCharge.Wizard.View.MyAccount', [
    'Wizard.View',
    'SC.Configuration',
    'GlobalViews.Message.View',
    'underscore',
    'Utils'
], function StudentAccountWizardView (
    WizardView,
    Configuration,
    GlobalViewsMessageView,
    _,
    Utils
) {
    'use strict';

    _.extend(WizardView.prototype, {
        getContext: _.wrap(WizardView.prototype.getContext, function initialize(e) {
            var context = e.apply(this, _.toArray(arguments).slice(1));
            var self = this;
            console.log('this context', this);
            _.defer(function() {
                var paymentmethod = jQuery('.order-wizard-paymentmethod-selector-module-button.selected').text();
                // var config = Configuration.get('checkoutcharge');

                // if (!config.active) {
                //     e.apply(this, _.toArray(arguments).slice(1));
                //     return true;
                // }
                
                // var disclaimer = config.disclaimer;
                // var percentage = config.percent;
                // var label = config.summarylabel;

                var disclaimer = 'test disclaimer';
                var percentage = 3;
                var label = 'Charge Test';

                if(paymentmethod.trim() == 'Credit / Debit Card') {
                    var globalViewMessage = new GlobalViewsMessageView({
                        message: disclaimer,
                        type: 'error',
                        closable: true
                    });

                    var messages = globalViewMessage.render().$el.html();
                    messages = '<div class="checkout-charge-container">'+ messages + '</div>';

                    jQuery('.checkout-charge-container').remove();
                    jQuery('.order-wizard-paymentmethod-selector-module-header-nav').after(messages);

                    var summary = self.wizard.model.get('payment');
                    var total = summary;
                    var totalPercentage = total * (parseInt(percentage) / 100);
                    totalPercentage = totalPercentage.toFixed(2);
                    total = parseFloat(total) + parseFloat(totalPercentage);
                    total = parseFloat(total);
                    total = total.toFixed(2);

                    totalPercentage = Utils.formatCurrency(totalPercentage);
                    total = Utils.formatCurrency(total);
                    
					var container = jQuery('.payment-wizard-summary-module-credits-subtotal');
					container.after(
						'<div class="order-wizard-cart-summary-shipping-cost-applied inpk-checkout-charge">'
                            +'<p class="payment-wizard-summary-module-grid-float">'
                                +'<span class="payment-wizard-summary-module-credits-subtotal-value">'
                                    +totalPercentage
                                +'</span>'
                                +label
                            +'</p>'
                        +'</div>'
                    )
                    
                    var totalContainer = jQuery('.payment-wizard-summary-module-estimated').find('.payment-wizard-summary-module-estimated-total-value');
                    totalContainer.html(total);
                }
                else {
                    jQuery('.checkout-charge-container').remove();
                }
            });

            return context;
        })
     ,   submit: _.wrap(WizardView.prototype.submit, function submit(e) {

            var self = this;
            var paymentmethod = jQuery('.order-wizard-paymentmethod-selector-module-button.selected').text();
            // var config = Configuration.get('checkoutcharge');

			// if (!config.active) {
            //     e.apply(this, _.toArray(arguments).slice(1));
            //     return true;
            // }

			// if(paymentmethod.trim() == 'Credit / Debit Card') {
            //     this.wizard.model.get('options')['custbody_nsps_add_charge'] =  "T";
            // }
            // else {
            //     this.wizard.model.get('options')['custbody_nsps_add_charge'] =  "F";
            // }

            console.log('self', self);

            e.apply(this, _.toArray(arguments).slice(1));
        })
    });
});
