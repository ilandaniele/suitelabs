define('IPKCheckoutCharge', [
  'IPKCheckoutCharge.LivePayment.Model'
  ], function BRITFormSite(
    IPKCheckoutChargeLivePaymentModel
  ) {
	'use strict';
  });
  