/*
	© 2017 NetSuite Inc.
	User may not copy, modify, distribute, or re-bundle or otherwise make available this code;
	provided, however, if you are an authorized user with a NetSuite account or log-in, you
	may use this code subject to the terms that govern your access and use.
*/

//@module Account
// ----------
// Handles account creation, login, logout and password reset
// module Account
define(
	'IPKCheckoutCharge.LivePayment.Model'
,	[
		'Application'
	,	'LivePayment.Model'
	,	'Configuration'
	,	'underscore'
	,	'Utils'
	]
,	function (
		Application
	,	LivePaymentModel
	,	Configuration
	,	_
	,	Utils
	)
{
	'use strict';
	
	Application.on('before:LivePayment.submit', function (Model, response) {

		var extensionsConfig = Configuration.get('extensions');

		//check if configuration exist, if not return unedited response
		if (!extensionsConfig || (!extensionsConfig.checkoutcharge && !extensionsConfig.checkoutcharge.active)) {
			return response;
		}

		var itemCharge = extensionsConfig.checkoutcharge.itemid;
		var percentCharge = extensionsConfig.checkoutcharge.percent;

		/*re-compute payment total and add credit card charge if type === 'creditcard'*/
		var paymentmethod = response.paymentmethods;//get payment method to check if type is creditcard
		nlapiLogExecution('ERROR', 'Test.LivePayment.Model => paymentmethod', JSON.stringify(paymentmethod))
		
		//check if creditcard type is creditcard, if not return normal response
		if (paymentmethod && paymentmethod.length && paymentmethod[0].type != 'creditcard'){
			return response;
		}

		//get invoices that has apply true
		var totalAmount = 0;
		var totalDue = 0;
		var invoices = response.invoices;
		invoices = _.findWhere(invoices, {apply: true});
		nlapiLogExecution('ERROR', 'Test.LivePayment.Model => invoices', JSON.stringify(invoices))

		if (!_.isArray(invoices)) {
			invoices = [invoices];
		}

		//loop invoice then add new line fopr item charge before creating payment
		_.each(invoices, function(value, index){
			nlapiLogExecution('ERROR', 'Test.LivePayment.Model => value', JSON.stringify(value))
			nlapiLogExecution('ERROR', 'Test.LivePayment.Model => index', JSON.stringify(index))
			var invoiceRec = nlapiLoadRecord('invoice', value.internalid);
			var dueAmount = value.due;
			var amount = value.amount;
			var rateAmount = amount * (percentCharge / 100);
			rateAmount = rateAmount.toFixed(2);
			var newDueAmount = parseFloat(rateAmount) + parseFloat(dueAmount);
			var newAmount = parseFloat(rateAmount) + parseFloat(amount);
			totalAmount += newAmount;
			totalDue += dueAmount;
			newDueAmount = newDueAmount.toFixed(2);
			newAmount = newAmount.toFixed(2);

			invoiceRec.selectNewLineItem('item');
			invoiceRec.setCurrentLineItemValue('item', 'item', itemCharge);
			invoiceRec.setCurrentLineItemValue('item', 'rate', rateAmount.toFixed(2));
			invoiceRec.commitLineItem('item');
			nlapiSubmitRecord(invoiceRec);

			//override payment amount and due base on new computed
			value.due = newDueAmount;
			value.due_formatted = Utils.formatCurrency(newDueAmount);
			value.amount = newAmount;
			value.amount_formatted = Utils.formatCurrency(amount);

		});

		//override summary base on new computed
		totalAmount = totalAmount.toFixed(2);
		totalDue = totalDue.toFixed(2);

		response.invoices_total = totalAmount;
		response.invoices_total_formatted = Utils.formatCurrency(totalAmount);
		response.payment = totalAmount;
		response.payment_formatted = Utils.formatCurrency(totalAmount);

		nlapiLogExecution('ERROR', 'Test.LivePayment.Model => after changes response ', JSON.stringify(response))

		return response
	});
});
