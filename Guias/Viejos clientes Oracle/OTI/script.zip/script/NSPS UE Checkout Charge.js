/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['N/search', 'N/record', 'N/runtime'],
    function(search, record, runtime) {
        var chargeobj = {
            itemid: 1823,
            percentage: 3
        };

        function afterSubmit(context) {
            customLogger('context', context);

            var curRec = context.newRecord;
            var addCharge = curRec.getValue({
                        fieldId: 'custbody_nsps_add_charge'
                    });
            var total = curRec.getValue({
                        fieldId: 'total'
                    });
            var id = curRec.id;
            customLogger('total', total);
            customLogger('addCharge', addCharge);
            customLogger('id', id);

            if (runtime.executionContext != runtime.ContextType.WEBSTORE || !addCharge) {
                return true;
            }

            var salesrec = record.load({
                type: 'salesorder',
                id: id,
                isDynamic: true,
            });

            var percentage = parseFloat(total) * (chargeobj.percentage / 100);
            percentage = parseFloat(percentage);
            percentage = percentage.toFixed(2);

            // var lineCount = curRec.getLineCount({
            //     sublistId: 'item'
            // });

            var lineNum = salesrec.selectNewLine({
                sublistId: 'item'
            });

            salesrec.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'item',
                value: chargeobj.itemid
            });

            salesrec.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'rate',
                value: percentage
                });
            salesrec.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'amount',
                value: percentage
            });
            salesrec.commitLine({
                sublistId: 'item'
            });

            salesrec.save({
                enableSourcing: true,
                ignoreMandatoryFields: true
            });

            return true;
        }

        function isEmpty(stValue) {
            if (stValue === '' || stValue == null || stValue == undefined) {
                return true;
            }
            if (stValue.constructor === Array && stValue.length == 0) {
                return true;
            }
            if (stValue.constructor === Object) {
                for (var i in stValue) {
                    if (stValue.hasOwnProperty(i)) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        function customLogger (title, details) {
            log.error({title : title, details : details});
        }

        return {
            afterSubmit: afterSubmit
        };
    });