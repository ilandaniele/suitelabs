/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(['N/search', 'N/record', './underscore', 'N/runtime'],
    function(search, record, lodash, runtime, tierlib) {
        function validateLine(context) {

            customLogger('Checkout Charge', 'Checkout Charge');

            var sublistName = context.sublistId;
            var currentRecord = context.currentRecord;

            if (runtime.executionContext != runtime.ContextType.WEBSTORE || sublistName != 'item') {
                customLogger('Checkout Charge total', 'not executed');
                return true;
            }

            var total = currentRecord.getValue({
                                    fieldId: 'total'
                                });
            var item = currentRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'item'
            });

            customLogger('Checkout Charge total', total);
            customLogger('Checkout Charge item', item);

            if (item == '1823') {
                var charge = parseFloat(total) * .03;

                currentRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    value: charge
                });
                currentRecord.setCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    value: charge
                });

            }

            return true;
        }

        function isEmpty(stValue) {
            if (stValue === '' || stValue == null || stValue == undefined) {
                return true;
            }
            if (stValue.constructor === Array && stValue.length == 0) {
                return true;
            }
            if (stValue.constructor === Object) {
                for (var i in stValue) {
                    if (stValue.hasOwnProperty(i)) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        function customLogger (title, details) {
            log.error({title : title, details : details});
        }

        return {
            validateLine: validateLine
        };
});